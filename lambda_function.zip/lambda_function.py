import json
import boto3
import pymysql
from botocore.exceptions import ClientError

# Initialize AWS clients
s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')

# RDS connection settings (ideally, these should be environment variables)
rds_host = "mydb.cpcg2s8giqef.us-east-1.rds.amazonaws.com"
db_username = "admin"
db_password = "Admin123"
db_name = "rds"
admin_email_topic_arn = "arn:aws:sns:us-east-1:992382835943:demotopic"

# Function to fetch employee details from RDS based on empid
def fetch_employee_from_rds(empid):
    try:
        connection = pymysql.connect(host=rds_host, user=db_username, passwd=db_password, db=db_name)
        cursor = connection.cursor()

        query = "SELECT * FROM employee WHERE empid=%s"
        cursor.execute(query, (empid,))
        result = cursor.fetchone()
        connection.close()
        
        if result:
            return {
                "empid": result[0],
                "first_name": result[1],
                "last_name": result[2],
                "primary_skills": result[3],
                "location": result[4]
            }
        else:
            return None
    except pymysql.MySQLError as e:
        print(f"Error fetching employee from RDS: {str(e)}")
        return None

# Function to fetch the image URL from DynamoDB based on empid
def fetch_image_url_from_dynamodb(empid):
    table = dynamodb.Table('employee_image_table')
    try:
        response = table.get_item(Key={'empid': int(empid)})  # Ensure empid is an int
        if 'Item' in response:
            return response['Item'].get('image_url')
        return None
    except ClientError as e:
        print(f"Error fetching image URL from DynamoDB: {str(e)}")
        return None

# Function to send email via SNS
def send_email_via_sns(subject, message):
    try:
        sns.publish(
            TopicArn=admin_email_topic_arn,
            Subject=subject,
            Message=message
        )
        print("Email sent successfully.")
    except ClientError as e:
        print(f"Error sending email via SNS: {str(e)}")

# Main Lambda handler function
def lambda_handler(event, context):
    # Check if 'Records' exists in the event
    if 'Records' not in event or len(event['Records']) == 0:
        print("No records found in event.")
        return {
            'statusCode': 400,
            'body': json.dumps('No records found.')
        }

    # Get the object key from the S3 event
    object_key = event['Records'][0]['s3']['object']['key']
    print(f"Received object key: {object_key}")

    # Extract empid from the object key (assuming format emp-id-XXX_image_file)
    parts = object_key.split('_')
    if len(parts) > 0:
        empid_part = parts[0]  # This should be 'emp-id-XXX'
        empid = empid_part.split('-')[2]  # Extracting correct empid
    else:
        print(f"Unexpected object key format: {object_key}")
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid object key format.')
        }

    # Fetch employee details from RDS
    employee_data = fetch_employee_from_rds(empid)

    # Fetch image URL from DynamoDB
    image_url = fetch_image_url_from_dynamodb(empid)

    # If no employee data found, log an error and exit
    if not employee_data:
        print(f"No employee found with empid: {empid}")
        return {
            'statusCode': 404,
            'body': json.dumps(f'No employee found with empid: {empid}')
        }

    # If no image URL found, log a warning
    if not image_url:
        print(f"No image URL found for empid: {empid}")
        image_url = "No image URL found"

    # Prepare metadata summary
    metadata_summary = {
        "Employee ID": empid,
        "First Name": employee_data['first_name'],
        "Last Name": employee_data['last_name'],
        "Primary Skills": employee_data['primary_skills'],
        "Location": employee_data['location'],
        "Image URL": image_url
    }

    # Prepare the message for the admin
    subject = f"Employee Onboarded ID: {empid}"
    message = f"New employee Added.\n\nDetails:\n{json.dumps(metadata_summary, indent=2)}"

    # Send email to admin via SNS
    send_email_via_sns(subject, message)

    return {
        'statusCode': 200,
        'body': json.dumps('Lambda executed successfully!')
        }

